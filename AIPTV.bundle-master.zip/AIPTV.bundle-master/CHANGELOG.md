Version 0.8 (2015-08-26):
* Enhanced Play Video

Version 0.7 (2015-08-24):
* Reenable art feature

Version 0.6 (2015-08-23):
* Enabled optimize for streaming
* Added audio codec in info.plist

Version 0.5 (2015-08-23):
* Momentanously disable art feature
* Let PMS decide about Media Object details

Version 0.4 (2015-08-22):
* Fixed for Plex Home Theater

Version 0.2 (2015-08-20):
* Updated Sample Playlist

Version 0.2 (2015-07-16):
* Added Extended M3U support

Version 0.1 (2015-07-14):
* Initial Version
